namespace API.Entity
{
    public class Alojamiento
    {
        public int Id { get; set; }
        public string codAlojamiento { get; set; }
        public string alojamiento { get; set; }
        public string direccion { get; set; }
        public string observaciones { get; set; }



    }
}