export class Alojamiento {
  id: number;
  codAlojamiento: string;
  alojamiento: string;
  direccion: string;
  observaciones: string;
}
