import { Alojamiento } from './alojamiento';

describe('Alojamiento', () => {
  it('should create an instance', () => {
    expect(new Alojamiento()).toBeTruthy();
  });
});
