import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Alojamiento } from '../../Classes/alojamiento';
import { RestService } from '../../services/rest.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css'],
})
export class EditComponent implements OnInit {
  form: FormGroup;
  static alojamiento: Alojamiento = new Alojamiento();

  constructor(
    private restService: RestService,
    private formBuilder: FormBuilder,
    private router: Router,
    public snackBar: MatSnackBar
  ) {
    this.form = formBuilder.group({
      codAlojamiento: [
        EditComponent.alojamiento.codAlojamiento,
        Validators.required,
      ],
      alojamiento: [EditComponent.alojamiento.alojamiento, Validators.required],
      direccion: [EditComponent.alojamiento.direccion, Validators.required],
      observaciones: [
        EditComponent.alojamiento.observaciones,
        Validators.required,
      ],
    });
  }

  updateAlojamiento() {
    EditComponent.alojamiento.codAlojamiento = this.form.value.codAlojamiento;
    EditComponent.alojamiento.alojamiento = this.form.value.alojamiento;
    EditComponent.alojamiento.direccion = this.form.value.direccion;
    EditComponent.alojamiento.observaciones = this.form.value.observaciones;
    this.restService
      .updateAlojamiento(EditComponent.alojamiento)
      .subscribe(() => {
        this.router.navigate(['']);
        this.snackBar.open('Alojamiento updated correctly.', 'Exit', {
          duration: 2000,
        });
      });
  }
  get getUpdatedAlojamientoId() {
    return EditComponent.alojamiento.id;
  }

  ngOnInit(): void {}
}
