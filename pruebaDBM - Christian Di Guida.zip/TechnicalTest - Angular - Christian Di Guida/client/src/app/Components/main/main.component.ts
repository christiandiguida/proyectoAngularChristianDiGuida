import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule, Routes } from '@angular/router';
import { Alojamiento } from 'src/app/Classes/alojamiento';
import { RestService } from 'src/app/services/rest.service';
import { EditComponent } from '../edit/edit.component';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
})
export class MainComponent implements OnInit {
  alojamientos: Alojamiento[] = [];
  dataSource = this.alojamientos;
  displayedColumns: string[] = [
    'Identifier',
    'CodAlojamiento',
    'Alojamiento',
    'Direccion',
    'Observaciones',
    'Edit',
  ];
  constructor(
    private http: HttpClient,
    private restService: RestService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  editAlojamiento(alojamiento: Alojamiento) {
    EditComponent.alojamiento = alojamiento;
    this.router.navigate(['/edit']);
  }
  ngOnInit(): void {
    this.restService.getAlojamientos().subscribe((a) => {
      this.alojamientos = a;
    });
  }
}
