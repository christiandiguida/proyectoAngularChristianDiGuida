import {
  HttpClient,
  HttpHeaderResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Alojamiento } from '../Classes/alojamiento';

@Injectable({
  providedIn: 'root',
})
export class RestService {
  constructor(private http: HttpClient) {}

  getAlojamientos(): Observable<Alojamiento[]> {
    return this.http.get<Alojamiento[]>('https://localhost:5001/alojamientos/');
  }
  updateAlojamiento(alojamiento: Alojamiento) {
    return this.http.put<Alojamiento>(
      'https://localhost:5001/alojamientos/',
      alojamiento
    );
  }
}
